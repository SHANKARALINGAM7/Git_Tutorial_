strings = list(map(str,input().split()))

freq = {}
for s in strings:
    freq[(len(s),s)] = s

l = list(freq.keys())
l.sort()

for size, val in l[::-1]:
    print(val)