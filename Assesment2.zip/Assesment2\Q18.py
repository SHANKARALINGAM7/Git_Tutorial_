strings = list(map(str,input().split(",")))
charset = list(map(str, input().split(",")))

freq = {}
for char in charset:
    if char in freq:
        freq[char] += 1
    else:
        freq[char] = 1

can_make = []
for string in strings:
    string = string.strip()
    curr_freq = {}
    count = 0
    for char in string:
        if char in curr_freq:
            curr_freq[char] += 1
            if curr_freq[char] > freq[char]:
                break
            else:
                count += 1
        else:
            curr_freq[char] = 1
            count += 1
        if char not in freq:
            break


    if count == len(string):
        can_make.append(string)

print(can_make)