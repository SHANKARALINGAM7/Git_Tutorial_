# # Step 1: Create a custom exception (must inherit from Exception)
# class MyCustomError(Exception):
#     pass   # You can add custom logic here if needed
#
# # Step 2: Use the custom exception
# def check_number(x):
#     if x < 0:
#         raise MyCustomError("Negative numbers are not allowed!")  # raise custom exception
#     else:
#         print("Number is valid:", x)
#
# # Step 3: Handle the exception
# try:
#     check_number(-5)
# except MyCustomError as e:
#     print("Caught custom exception:", e)
print(type(Exception))
print(type(NameError))