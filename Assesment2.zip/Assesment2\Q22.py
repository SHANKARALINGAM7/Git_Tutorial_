s1 = input("enter String1 :")
s2 = input("enter String2 :")

new_string = ""
start = 0
end = len(s2) - 1
while start < len(s1) and end >= 0:
    new_string += s1[start]
    start += 1
    new_string += s2[end]
    end -= 1
if end > -1:
    new_string += s2[:end+1]
if start < len(s1):
    new_string += s1[start:]

print(new_string)