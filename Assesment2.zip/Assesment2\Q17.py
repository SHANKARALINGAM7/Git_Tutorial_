values = input()
k = int(input())

l = []
i = 0

while i < len(values):
    if values[i] == '(':
        value = tuple()
        while i < len(values) and values[i] != ')':
            if values[i].isdigit():
                value = value + (values[i],)
            i += 1
        if value and len(value) != k:
            l.append(value)
    i += 1

print(len(l))