K = int(input("Enter K :"))
string = list(input("Enter string: "))

alphabets = "abcdefghijklmnopqrstuvwxyz"
ALPHABETS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
for ind in range(K,len(string)):
    val = string[ind]
    if val.islower():
        string[ind] = alphabets[-(ord(val) - ord('a') + 1)]
    else:
        string[ind] = ALPHABETS[-(ord(val) - ord('A') + 1)]

print("".join(string))
