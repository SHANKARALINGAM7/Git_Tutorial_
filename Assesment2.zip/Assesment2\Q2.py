s = input("Enter the String: ")
low = ""
up = ""
for word in s:
    if word.islower():
        low += word
    else:
        up += word

print(low + up)