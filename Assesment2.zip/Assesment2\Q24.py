def max_min_temp_and_humidity(temperature):

    print("Max Temperature",max([temp for temp,humidity in temperature]))
    print("Min Temperature",min([temp for temp,humidity in temperature]))

    print("Max Humidity",max([humidity for temp,humidity in temperature]))
    print("Min Humidity",min([humidity for temp,humidity in temperature]))

def avg_temp_and_humidity(temperature):
    print("Avg Temperature",sum([temp for temp ,humidity in temperature])/len(temperature))
    print("Avg Humidity",sum([humidity for temp ,humidity in temperature])/len(temperature))

def exceeds_threshold(temperature, T , H):
    print("Exceeds threshold : ")
    for temp,humidity in temperature:
        if temp > T or humidity > H:
            print("Temperature : ",temp,"Humidity :",humidity)


N = int(input("Enter N : "))
temperature =[]
for i in range(N):
    temperature.append(tuple(map(int,input("Enter temperature: ").split())))
T = int(input("Enter Threshold: "))
H = int(input("Enter Humidity: "))

max_min_temp_and_humidity(temperature)
avg_temp_and_humidity(temperature)
exceeds_threshold(temperature, T, H)