strings = list(map(str,input().split()))
unique_emails = set()

for string in strings:
    local_name = ""
    for ind,char in enumerate(string):
        if char == '.':
            continue
        if char == '+':
            break
        local_name += char

    domain_name = ""
    for char in string[::-1]:
        if char == '@':
            break
        else:
            domain_name = char + domain_name
    domain_name = '@' + domain_name
    unique_emails.add(local_name + domain_name)

print(len(unique_emails))