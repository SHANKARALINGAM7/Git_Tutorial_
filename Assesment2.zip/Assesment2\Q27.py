string = input("Enter string: ")
k = int(input("Enter K:"))

freq = {}
for char in string:
    if char in freq:
        freq[char] += 1
    else:
        freq[char] = 1

flag = True
for char, count in freq.items():
    if count == 1:
        k -= 1
    if k == 0:
        print(char)
        flag = False
        break

if flag:
    print("Less than k non-repeating characters in input.")