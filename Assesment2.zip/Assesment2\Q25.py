def remove_duplicates(lst):
    lst = dict.fromkeys(lst)
    return lst

def sum_of_uniques(lst):
    print("Sum : ",sum(lst))

def mean_of_uniques(lst):
    print("Mean : ",round(sum(lst) / len(lst), 2))

def max_and_min_in_uniques(lst):
    print("Max : ",max(lst))
    print("Min : ",min(lst))

N = int(input("Enter N: "))
numbers = []
for i in range(N):
    numbers.append(int(input("Enter number: ")))

while True:
    print("""1. Remove duplicates from the list.\n
            2. Calculate the sum of unique values in the list.\n
            3. Calculate the mean of unique values in the list.\n
            4. Find the largest and smallest unique values in the list.\n
            5. Quit the program""")

    match(int(input("Enter N: "))):
        case 2:
            sum_of_uniques(numbers)
        case 3:
            mean_of_uniques(numbers)
        case 4:
            max_and_min_in_uniques(numbers)
        case 1:
            numbers = remove_duplicates(numbers)
        case 5:
            break

print("List with removed duplicates : ",list(numbers.keys()))