N , element = map(int, input("Enter N, element : ").split())
numbers = list(map(int, input("Enter the elements :").split()))
count = 0
for num in numbers:
    if num == element:
        count += 1

print(count)