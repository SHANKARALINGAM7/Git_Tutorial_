N = int(input("Enter N : "))
unique_set = set()
numbers = []

for _ in range(N):
    number = int(input())
    if number not in unique_set:
        unique_set.add(number)
        numbers.append(number)

print("Unique List : ",numbers)