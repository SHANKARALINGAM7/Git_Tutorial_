N = int(input())
numbers = list(map(int, input().split()))
numbers.sort()
uniques = {}
for i in range(N):
    left = i + 1
    right = len(numbers) - 1
    while left < right:
        cal = numbers[i] + numbers[left] + numbers[right]
        if cal == 0:
            triplet = (numbers[i], numbers[left], numbers[right])
            if triplet not in uniques:
                uniques[triplet] = 1
            left += 1
            right -= 1
        elif cal > 0:
            right -= 1
        else:
            left += 1

print(list(uniques.keys()))