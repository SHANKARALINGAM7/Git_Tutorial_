N = int(input("Enter the number : "))
numbers = list(map(int,input().split()))

if N % 2 == 0:
    print((numbers[N // 2] + numbers[N // 2 - 1]) / 2)
else:
    print(numbers[N // 2])