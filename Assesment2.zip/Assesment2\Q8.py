s1 = input().split()
s2 = input().split()
uncommon = []

hash = {}

for s in [s1,s2]:
    for word in s:
        if word not in hash:
            hash[word] = 0
        hash[word] += 1

counter = 0
for word in hash:
    if hash[word] == 1:
        uncommon.append(word)
print(uncommon)