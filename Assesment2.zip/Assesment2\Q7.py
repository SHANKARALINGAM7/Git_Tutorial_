N = int(input())
numbers = list(map(int, input().split()))
counter = 0
for i in range(N):
    for j in range(i+1,N):
        for k in range(j+1,N):
            for l in range(k+1,N):
                if any([numbers[i] * numbers[j] == numbers[k] * numbers[l],
                       numbers[i] * numbers[k] == numbers[j] * numbers[l],
                       numbers[i] * numbers[l] == numbers[k] * numbers[j]]):
                    counter += 8

print(counter)