N = int(input())
numbers = list(map(int, input().split()))
for curr in range(1,N+1):
    if curr not in numbers:
        print(curr)
