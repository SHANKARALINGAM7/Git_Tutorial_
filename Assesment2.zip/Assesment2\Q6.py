N = int(input())
strings = list(map(str, input().split()))
hash = {}
for string in strings:
    temp = tuple(sorted(string))
    if temp not in hash:
        hash[temp] = []
    hash[temp].append(string)

print([*hash.values()])