from itertools import permutations

string = input("Enter a string: ")
N = int(input("Enter N:"))
strings = []
for _ in range(N):
    strings.append(input())

index = []
s = ["".join(perm) for perm in permutations(strings)]
for word in s:
    if word in string:
        index.append(string.find(word))

print(index.sort())