numbers = input().split(" ")
print(numbers)
counter = 0
for i in range(len(numbers)):
    number = numbers[i]
    #print('({},{})'.format(number[3], number[1]))
    #(5, 6)(1, 2)(6, 5)(9, 1)(6, 5)(2, 1)
    counter += numbers[i:].count('({},{})'.format(number[3], number[1]))

print(counter)