tuples = eval(input("Enter Tuples List: "))
k = int(input("Enter K: "))

result = []
freq = {}
for t in tuples:
    #print(t)
    if t[0] in freq and freq[t[0]] < k:
        freq[t[0]] += 1
        result.append(t)
    elif t[0] not in freq:
        freq[t[0]] = 1
        result.append(t)

print(result)