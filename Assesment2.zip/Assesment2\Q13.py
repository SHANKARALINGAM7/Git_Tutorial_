n = int(input())
numbers = list(map(int, input().split()))
positive = []
negative = []

for number in numbers:
    if number >=0:
        positive.append(number)
    else:
        negative.append(number)

print("Original List : ",numbers)
print("Positive List : ",positive)
print("Negative List : ",negative)