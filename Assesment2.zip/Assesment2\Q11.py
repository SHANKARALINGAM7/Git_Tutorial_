s1 = list(input())
s2 = list(input())

s1[2], s2[2] = s2[2], s1[2]

print(''.join(s1),''.join(s2),sep='\n')