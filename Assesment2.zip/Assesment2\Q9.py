from multiprocessing.reduction import duplicate

n = int(input())
numbers = list(map(int, input().split()))
hash = {}

for number in numbers:
    if number not in hash:
        hash[number] = 0
    hash[number] += 1

duplicate = 0
missing = 0
for curr in range(1,n+1):
    if curr not in hash:
        missing  = curr
    elif hash[curr] == 2:
        duplicate = curr


print([duplicate, missing])