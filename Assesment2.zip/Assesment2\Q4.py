N = int(input())
numbers = list(map(int, input().split()))
element = int(input())
print(element in numbers)