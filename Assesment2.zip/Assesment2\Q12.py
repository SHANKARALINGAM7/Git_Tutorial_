s = input().split()

print("{}{}{}".format(s[0],s[1],s[2]))
print("{1}{0}{2}".format(s[0],s[1],s[2]))
print("{s1}{s2}{s3}".format(s1 = s[2], s2 = s[1], s3 = s[0]))

