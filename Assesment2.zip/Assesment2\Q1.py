s = input()
s = s.split(' ')

for word in s:
    if word.isalnum() and any(c.isalpha() for c in word) and any(c.isdigit() for c in word):
        print(word)
