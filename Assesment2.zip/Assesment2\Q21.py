string = input("Enter the string: ")

lowercase = 0
uppercase = 0
non_letters = 0

for char in string:
    if char.islower():
        lowercase += 1
    elif char.isupper():
        uppercase += 1
    else:
        non_letters += 1

print("lowercase",lowercase)
print("uppercase",uppercase)
print("non_letters",non_letters)