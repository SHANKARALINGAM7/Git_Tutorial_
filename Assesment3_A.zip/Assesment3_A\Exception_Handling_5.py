class Zero_order_error(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)


class NegativeValueError(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)


class Ecommerce:
    def __init__(self,item_name,quantity,price):
        self.item_name = item_name
        self.quantity = quantity
        self.price = price

    def validate_value(self,val):
        if val < 0:
            raise NegativeValueError("Value must be greater than 0")

    def validate_order(self,order):
        if not order:
            raise Zero_order_error("Order cannot be empty")



while True:
    try:
        items = eval(input("Enter items"))
        cost = 0
        for item in items:
            item_name = item[0]
            quantity = int(item[1])
            price = int(item[2])
            obj = Ecommerce(item_name, quantity, price)
            obj.validate_value(quantity)
            obj.validate_value(price)
            obj.validate_order(obj)
            cost += price * quantity

        print("Total cost : ", cost)

    except Zero_order_error as e:
        print(e)
    except NegativeValueError as e:
        print(e)
    except ValueError as e:
        print("Enter a valid number")