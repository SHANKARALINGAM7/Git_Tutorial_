class InvalidUsernameException(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(message)

class InvalidPasswordException(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(message)



class Authentication:
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def validate_username(self,username):
        if len(username) < 6 or len(username) > 30:
            raise InvalidUsernameException("username length must be between 6 and 30")
        elif not username[0].isalpha():
            raise InvalidUsernameException("First character should be alphabets (a-z) (A-Z)")
        else:
            for char in username:
                if not char.isalnum() and char != '_':
                    raise InvalidUsernameException("""username  only contain alphanumeric characters (a-z, A-Z, 0-9)
    and underscores (_)""")

        return True





    def validate_password(self,password):
        special = "!@#$%^&*()-+"
        uppercase = False
        lowercase = False
        digit = False
        special_char = False

        if len(password) < 8:
            raise InvalidPasswordException("Password must be at least 8 characters long")
        for char in password:
            if char in special:
                special_char = True
            if char.isupper():
                uppercase = True
            if char.islower():
                lowercase = True
            if char.isdigit():
                digit = True

        if not special_char:
            raise InvalidPasswordException("Password must contain at least one special character")
        if not uppercase:
            raise InvalidPasswordException("Password must contain at least one uppercase letter")
        if not lowercase:
            raise InvalidPasswordException("Password must contain at least one lowercase letter")
        if not digit:
            raise InvalidPasswordException("Password must contain at least one digit")

        return True



while True:
    try:
        username = input("Enter Username :")
        password = input("Enter Password :")
        obj = Authentication(username, password)
        ret1 = obj.validate_username(username)
        ret2 = obj.validate_password(password)

        if ret1 and ret2:
            print("Welcome :", username)

    except InvalidUsernameException as error:
        print(error)
    except InvalidPasswordException as error:
        print(error)