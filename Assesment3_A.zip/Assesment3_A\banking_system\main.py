from Assesment3_A.banking_system.account import account_management
from Assesment3_A.banking_system.loan import EMI
from Assesment3_A.banking_system.transactions import Transactions

print("Welcome to Banking System!")
obj = None

while True:
    print("Choose an option : ")
    print("1. Create New Account")
    print("2. Check Balance")
    print("3. Deposit")
    print("4. Withdraw")
    print("5. Calculate EMI")
    print("6. Exit")
    choice = input("Enter Choice : ")

    match choice:
        case "1":
            obj = account_management()
            obj.create_account()
        case "2":
            obj.check_balance()
        case "3":
            transaction = Transactions(obj)
            transaction.deposit()
        case "4":
            transaction = Transactions(obj)
            transaction.withdraw()
        case "5":
            emi_obj = EMI()
            emi_obj.calculate_emi()
        case "6":
            break
