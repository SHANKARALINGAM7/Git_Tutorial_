
class PayOutOfBoundsException(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)

class Account_Management:
    def __init__(self):
        self.current_balance = 80000
        self.max_transaction_limit =  30000

    def withdraw(self, amount):
        if amount > self.max_transaction_limit:
            raise PayOutOfBoundsException("Transaction limit exceeded")

        if amount > self.current_balance:
            raise PayOutOfBoundsException("Insufficient balance")

        self.current_balance -= amount
        print("Current Balance : ", self.current_balance)

obj = Account_Management()
while True:
    try:
        amount = int(input("Enter Amount :"))
        obj.withdraw(amount)
        print("Amount withdrawn successfully")
    except PayOutOfBoundsException as error:
        print("Exception : ",error)