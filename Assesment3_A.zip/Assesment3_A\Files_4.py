

def split_file(N):

    no_of_lines = 0
    content = []
    with open('bigfile.txt','r') as f:
        content = f.readlines()
        no_of_lines = len(content)

    no_of_files = int(round(no_of_lines / N))
    curr = 0
    for i in range(1,no_of_files + 1):
        with open('part{}.txt'.format(i),'a') as f:
            for _ in range(N):
                if curr < len(content):
                    f.write(content[curr])
                    curr += 1

N = int(input("Enter N: "))
split_file(N)