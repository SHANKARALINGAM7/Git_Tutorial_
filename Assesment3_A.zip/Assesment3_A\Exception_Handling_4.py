class InvalidAgeError(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)

class SeatLimitError(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)

class Flight_booking_system:
    def __init__(self,name,age,seats):
        self.name = name
        self.age = age
        self.seats = seats

    def validate_seats(self,seats):
        if seats > 6:
            raise SeatLimitError("Seats cannot be greater than 6")

    def validate_age(self,age):
        if age <= 0 or age > 120:
            raise InvalidAgeError("Age must be valid between 1 and 120")


while True:
    try:
        name = input("Enter your name: ")
        age = int(input("Enter your age: "))
        seats = int(input("Enter your seats: "))

        obj = Flight_booking_system(name,age,seats)
        obj.validate_age(age)
        obj.validate_seats(seats)

        print("Flight booking Successful for ",name)

    except ValueError as e:
        print(e)
    except InvalidAgeError as e:
        print(e)
    except SeatLimitError as e:
        print(e)
