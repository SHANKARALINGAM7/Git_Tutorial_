from Assesment3_A.ecommerce import products, cart

def calculate_discount(discount):
    discount = ext_discount(discount)
    PRODUCTS = products.products
    CART = cart.cart

    price = 0
    for product in PRODUCTS:
        if product[1] in CART:
            price += product[2]

    before = price
    price = (price // 100 ) * discount

    return (price, before)

def ext_discount(disc):
    return int(disc[-2:])

