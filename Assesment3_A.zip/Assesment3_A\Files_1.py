
def find_and_replace(string, replacement):

    with open('Files_1.txt', 'r+') as file:
        content = file.read()
        updated_content = content.replace(string,replacement)
        file.seek(0)
        file.write(updated_content)
        file.truncate()
        file.seek(0)
        print(file.read())


string, replacement = map(str,input('Enter a string: ').split())
find_and_replace(string, replacement)