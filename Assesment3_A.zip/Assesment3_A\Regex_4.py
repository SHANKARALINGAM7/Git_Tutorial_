import re

def same_letters_word(string):
    pattern = r'\b([a-zA-Z]\w*[a-zA-Z])\b'
    matches = [word for word in re.findall(pattern, string, flags=re.IGNORECASE)
               if word[0].lower() == word[-1].lower()]
    print(matches)


string = input('Enter a string: ')
same_letters_word(string)