def shuffle_list(numbers):
    result = []
    for i in range(N):
        result.append(numbers[i])
        result.append(numbers[i + N])

    return result


N = int(input("Enter N : "))
numbers = list(map(int, input().split()))

print(shuffle_list(numbers))