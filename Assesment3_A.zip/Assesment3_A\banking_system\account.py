
class account_management:
    def __init__(self,account_name = None,balance = None):
        self.account_name = account_name
        self.balance = balance

    def create_account(self):
        self.account_name = input("Enter Account Name: ")
        self.balance = int(input("Enter Amount: "))
        print("Account Created!")

    def check_balance(self):
        print("Balance : ",self.balance)
