from Assesment3_A.weather import forecast,alert,temperature

city = input("enter city name")
temp, rain = forecast.get_forecast(city)
print("TEMPERATURE : ",temp,"C","(",temperature.celsius_to_fahren(temp),"F)")
print("RAIN : ",rain,"%")
alert.alert_weather(temp,rain)
