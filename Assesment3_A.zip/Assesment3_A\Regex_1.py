import re

string = input("Enter a string: ")
hashtag = r'#\w+'
mention = r'@\w+'

print(re.findall(hashtag, string) + re.findall(mention, string))