import random

def password_generator(N):
    smallcase = 'abcdefghijklmnopqrstuvwxyz'
    uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    numbers = '0123456789'
    special = '!@#$%^&*()_+-=?'

    if N < 4:
        print('Password too short')
        return

    mand = [random.choice(smallcase), random.choice(uppercase),
            random.choice(numbers), random.choice(special)]

    all = smallcase + uppercase + numbers + special
    mand += [random.choice(all) for _ in range(N - 4)]

    random.shuffle(mand)
    print("Generated Password : ","".join(mand))

N = int(input("Enter N: "))
password_generator(N)