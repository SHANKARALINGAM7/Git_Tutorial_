

def remove_duplicate_line():
    uniques = {}

    with open('Data.txt', 'r+') as file:
        for line in file:
            if line not in uniques:
                uniques[line.rstrip('\n')] = line
       # print(uniques)

    with open('Cleaned.txt', 'w') as file:
        for key in uniques:
            file.write(key)
            file.write('\n')

remove_duplicate_line()