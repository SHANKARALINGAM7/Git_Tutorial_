from Assesment3_A.ecommerce.products import products

cart = set()

def add(product):
    cart.add(product)

def remove(product):
    cart.remove(product)

def show():
    for product in products:
        for curr_product in cart:
            if product[1] == curr_product:
                print(curr_product, product[2])