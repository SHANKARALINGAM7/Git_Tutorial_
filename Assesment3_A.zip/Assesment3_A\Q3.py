
def smallest_index_with_equal_value(numbers):
    for ind, number in enumerate(numbers):
        if number % 10 == number:
            return ind
    return -1


numbers = list(map(int, input("Enter Numbers :").split()))

smallest_index_with_equal_value(numbers)