from Assesment3_A.banking_system.account import account_management


class Transactions(account_management):
    def __init__(self, account_obj):
        self.account_obj = account_obj
        print("Transaction Processing!")

    def deposit(self):
        amount = int(input("Enter Deposit Amount: "))
        self.account_obj.balance += amount
        print("Updated Balance : ",self.account_obj.balance)
        print("Transaction Processed!")

    def withdraw(self):
        amount = int(input("Enter Withdraw Amount: "))
        if amount > self.account_obj.balance:
            print("Insufficient Amount")
        else:
            self.account_obj.balance -= amount
            print("Updated Balance : ",self.account_obj.balance)
            print("Transaction Processed!")