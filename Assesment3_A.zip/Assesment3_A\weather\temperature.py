
def celsius_to_fahren(celsius):
    return int((celsius * 9 / 5) + 32)