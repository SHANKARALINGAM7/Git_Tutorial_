import re

def extract_phone_numbers(string):
    pattern1 = r'\b\+91[-]\d{10}\b'
    pattern2 = r'\b91\d{10}\b'
    pattern3 = r'\b[6-9]\d{9}\b'

    print(re.findall(pattern1, string) + re.findall(pattern2, string)
          + re.findall(pattern3, string))

string = input('Enter a string: ')
extract_phone_numbers(string)