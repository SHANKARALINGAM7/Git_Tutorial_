import random

def get_forecast(city):
    return (random.randint(1,50),random.randint(1,100))
