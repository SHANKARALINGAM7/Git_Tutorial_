
def add_score(name,score):
    with open("leaderboard.txt","a") as file:
        file.write(name+"\t"+str(score)+"\n")

def show_leaderboard():
    with open("leaderboard.txt","r") as file:
        for _ in range(3):
            current = file.readline()
            print(current)