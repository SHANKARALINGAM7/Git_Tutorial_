
class EMI:
    def __init__(self):
        pass

    def calculate_emi(self):
        amount = int(input("Enter Amount: "))
        years = int(input("Enter Years: "))
        rate = int(input("Enter Rate of Interest: "))

        r = rate / (12 * 100)
        n = years * 12

        cal = (1 + r) ** n
        emi = (amount * r * cal) / (cal - 1)

        print("EMI Calculated :", round(emi, 2))