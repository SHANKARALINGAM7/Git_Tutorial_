import re

string = input('Enter a string: ')
pattern = r'<[^>]+>'

print(re.findall(pattern, string))