from Assesment3_A.ecommerce import cart,products, discounts


products.show()
print("Add Products ")
discount = ""
while True:
    l = list(map(str,input().split()))

    if not l:
        break
    action = l[0]
    product = l[1]

    if action == "Add":
        cart.add(product)
    elif action == "Remove":
        cart.remove(product)
    elif action == "Apply":
        discount = l[2]

cart.show()
price, before = discounts.calculate_discount(discount)
print("Price before discount :",before)
print("Discount :",before - price)
print("Price after discount :",price)