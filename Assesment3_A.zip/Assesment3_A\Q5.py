N = int(input())
numbers = list(map(int, input().split()))
numbers.sort()

ind = 0
max_len = 0

while ind < N:
    curr = ind
    while curr < N - 1 and numbers[curr] + 1 == numbers[curr + 1]:
        curr += 1
    max_len = max(max_len, curr - ind + 1)
    ind = curr + 1

print(max_len)
