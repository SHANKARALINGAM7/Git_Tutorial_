
def alert_weather(temperature, rain):
    if temperature > 38:
        print("ALERT : Heatwave alert")
    if rain > 70:
        print("ALERT : Heavy rain alert")