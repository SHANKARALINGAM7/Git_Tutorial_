
def reverse_file_content():

    reversed = []
    with open('input.txt','r') as file:
        for line in file:
            reversed.append([line])

    with open('output.txt','w+') as file:
        for line in reversed[::-1]:
            for word in line:
                file.write("".join(word[::-1]))
            #file.write('\n')
    print(reversed)



reverse_file_content()