

def keyword_search(keyword):
    lines = []
    curr = 1
    flag = True
    with open('document.txt', 'r') as file:
        for line in file:
            #print([line.rstrip('\n').lower()])
            if keyword in line.rstrip('\n').lower():
                lines.append(curr)
                flag = False
            curr += 1
    if flag:
        print("Keyword not found")
    else:
        print("Lines : ",*lines,sep=' ')


keyword = input('Enter keyword: ')
keyword_search(keyword)