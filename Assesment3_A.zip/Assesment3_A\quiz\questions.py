
questions = {
    "Capital of France?": "Paris",
    "5 + 3 = ?": "8",
    """Python is a snake or a programming language?""" : "programming language",
    "Python created by?" : "Guido van Rossum",
    "Square root of 16?": "4",
    "Largest planet in Solar System?": "Jupiter"
}