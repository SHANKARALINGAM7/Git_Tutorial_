def calculate_balance(initial_balance, transactions):
    current_balance = initial_balance
    for transaction in transactions:
        current_balance += transaction


initial_balance = int(input("Enter initial balance: "))
transactions = list(map(int, input().split()))

print(calculate_balance(initial_balance, transactions))