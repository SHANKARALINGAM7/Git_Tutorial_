from Assesment3_A.quiz import questions

def play_quiz():
    print("Lets play quiz!")

    score = 0
    for question in questions.questions:
        print(question)
        answer = input()
        if answer == questions.questions[question]:
            score += 1

    print("quiz finished")
    print("Your score is:", str(score) + "/" + str(len(questions.questions)))
    return score

