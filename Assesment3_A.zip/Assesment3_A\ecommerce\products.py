
products = [
            (101, "Laptop", 50000),
            (102, "Mouse", 1000),
            (201, "Phone", 30000),
            (202, "Keyboard", 30000),
            (203, "Case", 500)
]


def show():
    for product in products:
        print(product)