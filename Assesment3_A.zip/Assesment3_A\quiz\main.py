from Assesment3_A.quiz import game, leaderboard

name = input("Enter your name :")
score = game.play_quiz()
leaderboard.add_score(name,score)
leaderboard.show_leaderboard()