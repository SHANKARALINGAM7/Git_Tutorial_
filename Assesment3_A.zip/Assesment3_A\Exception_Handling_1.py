inventory = []

book_name = ""
book_quantity = 0
book_price = 0

try:
    book_name = input("Enter book name: ")
    book_quantity = int(input("Enter book quantity: "))
    book_price = int(input("Enter book price: "))
    inventory.append((book_name, book_quantity, book_price))
except ValueError:
    print("Invalid Input Format")
except IndexError:
    print("ArrayIndex Out Of Bounds")
else:
    print(inventory)